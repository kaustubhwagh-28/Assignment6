import java.util.*;

public class FirstNameComparator implements Comparator<Employee> {
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return o1.getFirstName().compareTo(o2.getFirstName());
	}
}
