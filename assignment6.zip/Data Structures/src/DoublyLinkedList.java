

public class DoublyLinkedList<T> {
	Node head;
	static class Node <T>{
		   
        T data;
        Node next;
        Node prev;
   
        
        Node(T d)
        {
            data = d;
            next = null;
            prev = null;
        }
}
	public  DoublyLinkedList insert(DoublyLinkedList list, T data)
    {
        // Create a new node with given data
        Node new_node = new Node(data);
        new_node.next = null;
        new_node.prev=null;
   
        // If the Linked List is empty,
        // then make the new node as head
        if (list.head == null) {
            list.head = new_node;
            new_node.prev=list.head;
        }
        else {
            // Else traverse till the last node
            // and insert the new_node there
            Node last = list.head;
            while (last.next != null) {
                last = last.next;
            }
   
            // Insert the new_node at last node
            last.next = new_node;
            new_node=last;
        }
   
        // Return the list by head
        return list;
    }
	 public  DoublyLinkedList delete(DoublyLinkedList list,
             T key)
{
// Store head node
Node currNode = list.head, temp = list.head;


// If head node itself holds the key to be deleted

if (currNode != null && currNode.data == key) {
list.head = currNode.next; // Changed head

// Display the message

// Return the updated List
return list;
}


// If the key is somewhere other than at head
//

// Search for the key to be deleted,
// keep track of the previous node
// as it is needed to change currNode.next

while (currNode != null && currNode.data != key) {
// If currNode does not hold key
// continue to next node
temp = currNode;
currNode = currNode.next;
}
//if the currNode is null
//then key is not present
if(currNode==null)
{
	System.out.println("not found");
	return list;
}

if(currNode.next== null && currNode.data==key)
{
	temp.next=null;
}
// If the key was present, it should be at currNode
// Therefore the currNode shall not be null
if (currNode.next != null) {
// Since the key is at currNode
// Unlink currNode from linked list
temp.next = currNode.next;
currNode.next.prev=temp;



}


//


// return the List
return list;
}
	 public static void printList(DoublyLinkedList list)
	    {
	        Node currNode = list.head;
	 
	        System.out.print("DoublyLinkedList: ");
	 
	        // Traverse through the LinkedList
	        while (currNode != null) {
	            // Print the data at current node
	            System.out.print(currNode.data + " ");
	 
	            // Go to next node
	            currNode = currNode.next;
	        }
	 
	        System.out.println();
	    }
	
	

}
