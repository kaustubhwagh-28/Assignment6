

public class SinglyCircularLinkedList<T> {
	public class Node<T>{  
        T data;  
        Node next;  
        public Node(T data) {  
            this.data = data;  
        }  
    }  
  
    //Declaring head and tail pointer as null.  
    public Node head = null;  
    public Node tail = null;  
  
    //This function will add the new node at the end of the list.  
    public SinglyCircularLinkedList insert(SinglyCircularLinkedList list, T data){  
        //Create new node  
        Node newNode = new Node(data);  
        //Checks if the list is empty.  
        if(list.head == null) {  
             //If list is empty, both head and tail would point to new node.  
            list.head = newNode;  
            list.tail = newNode;  
            newNode.next = head;  
        }  
        else {  
            //tail will point to new node.  
            tail.next = newNode;  
            //New node will become new tail.  
            tail = newNode;  
            //Since, it is circular linked list tail will point to head.  
            tail.next = head;  
        }
        return list;
    }
    public SinglyCircularLinkedList delete(SinglyCircularLinkedList list,T value)
    {
    	//if the list has only one node
    	//we assign head and tail to null
    	if((list.head.data==value) && list.head.next==list.head)
    	{
    		System.out.println("in");
    		list.head=null;
    		list.tail=null;
    		return list;
    	}
    	//if the node is at the start
    	//we update the tail
    	else 
    	if(list.head.data==value && list.head.next!=list.head)
    	{
    		
    		list.head=list.head.next;
    		tail.next=list.head;
    		return list;
    	}
    	Node CurrNode=list.head,prev=null;
    	//traversing till we dont find the value and till the end
    	//prev points to the node just before the currnode
    	while(CurrNode.next!=head && CurrNode.data!=value)
    	{
    		prev = CurrNode;
    		CurrNode = CurrNode.next;	
    		
    	}
        //if the node is at last position
    	if(CurrNode.next==head)
    	{
    		
    		prev.next=tail.next;
    		tail=prev;
    		//tail.next=head;
    		return list;
    	}
    	//if it is in the middle
    	else if(CurrNode.next!=head && CurrNode.data==value)
    	{
    		prev.next=CurrNode.next;
    		return list;
    	}
    	//if the CurrNode points to the head.it means no node is found
    	if(CurrNode==head)
    	{
    		System.out.println("data not found");
    	}
    	return list;
    }
     
  
    //Displays all the nodes in the list  
    public void display(SinglyCircularLinkedList list) {  
        Node current = list.head;  
        if(head == null) {  
            System.out.println("List is empty");  
        }  
        else {  
            System.out.println("Nodes of the circular linked list: ");  
             do{  
                //Prints each node by incrementing pointer.  
                System.out.print(" "+ current.data);  
                current = current.next;  
            }while(current != head);  
            System.out.println();  
        }  
    }  
  
     
}