import java.util.*;
public class DataStructures {
public static void main(String[]args)
{
	int arr[]= {1,2,3,4,5,6,7,8,9,10,11};
	System.out.println(BinarySearch.binarysearch(arr,9, 0, arr.length-1));
	 LinkedList list = new LinkedList();
	 
     //
     // ******INSERTION******
     //

     // Insert the values
	 
     list = list.insert(list, 1.3);
     list = list.insert(list, 2);
     list = list.insert(list, 'a');
     list = list.insert(list, 4);
     list = list.insert(list, 5);
     list = list.insert(list, 6);
     list = list.insert(list, 7);
    

     // Print the LinkedList
     LinkedList.printList(list);
    list= list.delete(list, 1.3);
    list= list.delete(list, 2);
    LinkedList.printList(list);
    queueusinglinkedlist q = new queueusinglinkedlist();
    q.enqueue(10);
    q.enqueue(20);
    q.display();
    q.dequeue();
    q.dequeue();
    q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);
    q.dequeue();
    q.display();
    System.out.println("Queue Front : " + q.front.key);
    System.out.println("Queue Rear : " + q.rear.key);
    StackUsingLinkedList obj = new StackUsingLinkedList();
    // insert Stack value
    obj.push(111);
    obj.push(222);
    obj.push(333);
    obj.push(444);

    // print Stack elements
    obj.display();

    // print Top element of Stack
    System.out.printf("\nTop element is %d\n", obj.peek());

    // Delete top element of Stack
    obj.pop();
    obj.pop();

    // print Stack elements
    obj.display();

    // print Top element of Stack
    System.out.printf("\nTop element is %d\n", obj.peek());
    TwoStacksusingArray ts = new TwoStacksusingArray(5);
    ts.push1(5);
    ts.push2(10);
    ts.push2(15);
    ts.push1(11);
    ts.push2(7);
    System.out.println("Popped element from"
                       + " stack1 is " + ts.pop1());
    ts.push2(40);
    System.out.println("Popped element from"
                       + " stack2 is " + ts.pop2());
    
    StackUsingArray stack=new StackUsingArray();
    stack.push(100);
    stack.push(200);
    stack.push(300);
    System.out.println(stack.pop());
    stack.display();
    DoublyLinkedList dl=new DoublyLinkedList();
    dl=dl.insert(dl, 'w');
    dl=dl.insert(dl, 'a');
    dl=dl.insert(dl, 4);
    dl.printList(dl);
    dl.delete(dl, 4);
    dl.delete(dl,'a');
    
    dl.delete(dl,'w');
    dl.delete(dl, 100);
    dl.printList(dl);
   
    
    SinglyCircularLinkedList sll=new SinglyCircularLinkedList();
    sll=sll.insert(sll, 1);
    //sll=sll.delete(sll, 1);
    sll.display(sll);
    sll=sll.insert(sll, 2);
    sll=sll.insert(sll, 3);
   sll=sll.insert(sll, 4);
    sll=sll.insert(sll, 5);
    sll=sll.insert(sll, 6);
    sll=sll.delete(sll, 2);
    sll=sll.delete(sll, 1);
    
   sll=sll.delete(sll, 3);
    sll.display(sll);
    System.out.println("growable array");
    DynamicArray da=new DynamicArray();
    da.push(0);
    da.push(1);
    da.push(2);
    da.push(3);
    da.push(4);
    da.push(5);
    da.print();
    System.out.println(da.getcapacity());
    da.pop();
    da.push(100, 1);
    da.print();
    
    
 
 

    
} 
  
     
}

