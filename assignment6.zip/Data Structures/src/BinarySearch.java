
public class BinarySearch {
public static int binarysearch(int arr[],int value,int start,int end)
{
if(end >=start)
{
	int mid= start + (end-start)/2;
	if(arr[mid]==value)
	{
		return mid;
	}
	else if(arr[mid] > value)
	{
		return binarysearch(arr,value,0,mid-1);
	}
	else
	{
		return binarysearch(arr,value,mid+1,end);
	}
	
}
return -1;
}
}
