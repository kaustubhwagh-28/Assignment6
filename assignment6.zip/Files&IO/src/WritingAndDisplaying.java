import java.io.*;
import java.util.*;
public class WritingAndDisplaying {
   public static void writingandDisplaying()
   {
	   
	   try {
	    String path="C:\\Users\\waghhkau\\Desktop\\Integer.txt";	   
	   FileWriter file = new FileWriter(path);
	   for(int i=1;i<=10;i++)
	   {
		   //converting to string
		   file.write(Integer.toString(i));
		   file.write(" \n");   
	   }
	   file.close();
	   File obj=new File(path);
	   
	   Scanner myReader = new Scanner(obj);
	      while (myReader.hasNextLine()) {
	        String data = myReader.nextLine();
	        System.out.println(data);
	        
	      }
         myReader.close();
	   
	   }
	   
	   catch(IOException e)
	   {
		   e.printStackTrace();
	   }
   }
}
