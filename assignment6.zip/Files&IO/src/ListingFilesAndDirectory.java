import java.io.*;
public class ListingFilesAndDirectory {
public static void listingfilesanddirectory(String path)
{
	File file = new File(path);

    // returns an array of all files
    String[] fileList = file.list();

    for(String str : fileList) {
      System.out.println(str);
    }
}
}
