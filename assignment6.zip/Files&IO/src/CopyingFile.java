import java.io.*;
public class CopyingFile {
public static void files(String path1,String path2)
{
	FileInputStream instream = null;
	FileOutputStream outstream = null;
	try{
	    File infile =new File(path1);
	    File outfile =new File(path2);

	    instream = new FileInputStream(infile);
	    outstream = new FileOutputStream(outfile);

	    byte[] buffer = new byte[1024];

	    int length;
	    /*copying the contents from input stream to
	     * output stream using read and write methods
	     */
	    while ((length = instream.read(buffer)) > 0){
	    	outstream.write(buffer, 0, length);
	    }
	    instream.close();
	    outstream.close();
}
	catch(IOException ioe){
		ioe.printStackTrace();
	 }
	
}
}
