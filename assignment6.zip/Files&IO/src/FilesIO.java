
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;
public class FilesIO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String result = "";
		InputStream inputStream;
    WritingAndDisplaying.writingandDisplaying();
    String source = "C:\\Users\\waghhkau\\Desktop\\java ss\\anatomy.png";
    String destination = "C:\\Users\\waghhkau\\Desktop\\anatomyduplicate.png";
    CopyingFile.files(source, destination);
    ListingFilesAndDirectory.listingfilesanddirectory("C:\\Users\\waghhkau\\Desktop\\ASSIGNMENT2");
    DisplayingFilesBasedonInput.display();
   

}
}
