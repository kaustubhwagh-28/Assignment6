import java.text.SimpleDateFormat;
import java.nio.file.Path;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.*
;public class DisplayingFilesBasedonInput {
public static void display()
{
	Scanner sobj=new Scanner(System.in);
	try {
	System.out.println("Enter the date in dd/mm/yyyy format only");
	String sDate1=sobj.nextLine();
	System.out.println("enter the size of file in kilobytes only");
	long s2=sobj.nextLong();
	List<String> accessedafter=new ArrayList<String>();
	List<String> accessedbefore=new ArrayList<String>();
	List<String> lesssizefiles=new ArrayList<String>();
	List<String> greatersizefiles=new ArrayList<String>();
	Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
	File file = new File("C:\\Users\\waghhkau\\Desktop");
	String[] fileList = file.list();
	
    for (String str:fileList)
    {
    File file2=new File(file+"\\"+str);
    Path file1=file2.toPath();
	BasicFileAttributes attr = Files.readAttributes(file1, BasicFileAttributes.class);
	//converting into kilobytes
	long length=file2.length()/1024;
	if(s2 > length)
	{
		lesssizefiles.add(str);
	}
	else
	{
		greatersizefiles.add(str);
	}
	
	FileTime time=attr.lastAccessTime();
	SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    
    Date d2 = df.parse(df.format(attr.creationTime().toMillis()));
	
    
    if(d2.compareTo(date1)> 0)
    { 
    	//if the file is accessed after the given time
    	accessedafter.add(str);
    }
    else if(date1.compareTo(d2)> 0)
    {
    	accessedbefore.add(str);
    }
    }
//	System.out.println("creationTime: " + attr.creationTime());
//	System.out.println("lastAccessTime: " + attr.lastAccessTime());
//	System.out.println("lastModifiedTime: " + attr.lastModifiedTime());
    System.out.println("Files accessed after the given time");
    System.out.println(accessedafter);
    System.out.println("Files accessed before the given time");
    System.out.println(accessedbefore);
    System.out.println("Files having size lesser than the given size");
    System.out.println(lesssizefiles);
    System.out.println("Files having size greater than the given size");
    System.out.println(greatersizefiles);
    
}
	catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
