import java.io.IOException;

public class ReadConfigMain {
	public static void main(String[] args) throws IOException {
		PropertyValues properties = new PropertyValues();
		properties.getPropValues();
	}
}
